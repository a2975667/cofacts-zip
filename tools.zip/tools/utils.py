import os
import pandas as pd
from datetime import timedelta
from dateutil import parser

def load_all_data(data_folder, adjust_tz=False):
    """
    Loads all CSV files from the specified data folder into a dictionary of DataFrames.
    
    Parameters:
    - data_folder: str, the path to the folder containing CSV data files.
    
    Returns:
    - A dictionary where each key is the name of a file (without extension) and the value is a DataFrame containing the file's data.
    """
    data_files = os.listdir(data_folder)
    data = {}

    print("Importing data. Usually takes 20 seconds.")
    for file in data_files:
        if file.startswith("."):  # Skip hidden files or directories
            continue
        print(f"Importing: {file}")
        file_path = os.path.join(data_folder, file)
        file_key = file.split(".")[0]
        df = pd.read_csv(file_path)

        if adjust_tz:
            datetime_columns = detect_datetime_columns(df, nrows=100)
            if datetime_columns:
                df = ensure_datetime_tz(df, datetime_columns, original_tz='UTC')
        data[file_key] = df
    
    print("Done.")
    return data

def load_tz_aware_csv(file_path, known_tz_colmns = []) -> pd.DataFrame:
    """
    Loads a CSV file that is already timezone aware into a DataFrame.
    
    Parameters:
    - file_path: str, the path to the CSV file to load.
    
    Returns:
    - pandas.DataFrame: The DataFrame containing the loaded CSV data.
    """
    df = pd.read_csv(file_path)
    datetime_columns = detect_datetime_columns(df, nrows=100)
    datetime_columns = datetime_columns + known_tz_colmns
    datetime_columns = list(set(datetime_columns))
    if datetime_columns:
        import datetime
        for c in datetime_columns:
            try:
                df[c] = df[c].apply(lambda x: datetime.datetime.fromisoformat(x))
            except:
                # see if the column has NaN values, if so convert them to NaT
                df[c] = df[c].apply(lambda x: datetime.datetime.fromisoformat(x) if x == x else pd.NaT)
                # print(f"Error converting column {c}.")
            # df[c] = df[c].apply(lambda x: datetime.datetime.fromisoformat(x))           
    return df

def ensure_datetime_tz(df, columns, original_tz='UTC'):
    """
    Ensures specified columns in a DataFrame are datetime objects in 'Asia/Taipei' timezone.
    
    Parameters:
    - df: pandas.DataFrame, the DataFrame containing the columns to be converted.
    - columns: str or list, the name(s) of the column(s) to convert.
    
    Returns:
    - pandas.DataFrame: The DataFrame with the datetime columns converted to 'Asia/Taipei' timezone.
    """
    # Check if columns is a single column name and not a list, and if so, convert it to a list
    if isinstance(columns, str):
        columns = [columns]
    
    for column in columns:
        # Ensure the column is a datetime object
        df[column] = pd.to_datetime(df[column])

        if df[column].dt.tz is None:
            print(f"Column '{column}' is not timezone-aware, applying timezone conversion.")

        # Check if datetime is timezone-aware and convert to 'Asia/Taipei' if it's not already
        if df[column].dt.tz is None and original_tz == 'UTC':
            df[column] = df[column].dt.tz_localize('UTC').dt.tz_convert('Asia/Taipei')

        if df[column].dt.tz is None and original_tz == 'Asia/Taipei':
            df[column] = df[column].dt.tz_localize('Asia/Taipei')
        
        if df[column].dt.tz is None and original_tz != 'Asia/Taipei' and original_tz != 'UTC':
            df[column] = df[column].dt.tz_localize(original_tz).dt.tz_convert('Asia/Taipei')
            
        else:
            print(f"Column '{column}' is already timezone-aware, the timezone is '{str(df[column].dt.tz)}'. Applying conversion if necessary to Asia/Taipei.")
            # If timezone-aware but not in 'Asia/Taipei', convert it
            if str(df[column].dt.tz) != 'Asia/Taipei':
                df[column] = df[column].dt.tz_convert('Asia/Taipei')

    return df

def filter_articles_by_event_timeframe(articles_df_raw, events_df_raw, key_terms=[], before_weeks=16, after_weeks=2):
    """
    Filters articles that are within a certain timeframe before and after event dates
    and contain specific key terms.
    
    Args:
    articles_df (pd.DataFrame): DataFrame containing articles with a 'createdAt' datetime column.
    events_df (pd.DataFrame): DataFrame containing events with a 'datetime' column.
    key_terms (list): List of key terms to filter articles by.
    before_weeks (int): Number of weeks before the event to start filtering articles.
    after_weeks (int): Number of weeks after the event to end filtering articles.
    
    Returns:
    pd.DataFrame: Filtered DataFrame containing only the valid articles.
    """
    # Adjust start_date and end_date based on event dates

    # we should not modify the original dataframes
    articles_df = articles_df_raw.copy()
    events_df = events_df_raw.copy()
    

    events_df.loc[:, 'start_date'] = events_df['datetime'] - timedelta(weeks=before_weeks)
    events_df.loc[:, 'end_date'] = events_df['datetime'] + timedelta(weeks=after_weeks)
    
    # Cross join to pair each article with every event
    combined_df = articles_df.assign(key=1).merge(events_df.assign(key=1), on='key').drop('key', axis=1)

    # Filter articles based on the timeframe condition
    timeframe_filtered_articles = combined_df[
        (combined_df['createdAt'] >= combined_df['start_date']) & 
        (combined_df['createdAt'] <= combined_df['end_date'])
    ]
    
    # If key_terms list is not empty, filter articles containing at least one of the key terms
    if key_terms:
        key_terms_pattern = "|".join(key_terms)
        valid_articles = timeframe_filtered_articles[timeframe_filtered_articles["text"].str.contains(key_terms_pattern)]
    else:
        valid_articles = timeframe_filtered_articles
    
    return valid_articles

def prepare_time_binned_data(df, event_ids, before_weeks, after_weeks, binning_hours, moving_average_day = 1, multiple_requests=False, use_rolling_avg=True):
    """
    Prepares time-binned data for analysis, filling in gaps and calculating cumulative sums or rolling averages.

    Args:
    df (pd.DataFrame): The articles dataframe with 'createdAt' and 'event_id' columns.
    event_ids (list): List of event IDs to filter the analysis on.
    before_weeks (int): Number of weeks before the event to consider.
    after_weeks (int): Number of weeks after the event to consider.
    binning_hours (int): The number of hours per bin for the analysis.
    multiple_requests (bool): Whether to count multiple requests for the same article.
    use_rolling_avg (bool): Whether to use rolling average instead of cumulative sum.

    Returns:
    pd.DataFrame: The final dataframe prepared for plotting or further analysis.
    """
    # Calculate time to event in hours
    df['time_to_event_hours'] = (df['createdAt'] - df['datetime']).dt.total_seconds() / 3600

    # Create bins based on the time to event
    df['time_bin'] = pd.cut(
        df['time_to_event_hours'],
        bins=pd.interval_range(start=-before_weeks*7*24, end=after_weeks*7*24, freq=binning_hours),
        labels=False
    )
    
    # Sort by event first, then by time_bin
    df = df.sort_values(by=["event_id", "time_bin"])

    # Aggregate articles by event_id and time_bin
    if multiple_requests:
        time_bin_counts = df.groupby(['event_id', 'time_bin']).agg({'request_count': 'sum'}).reset_index()
        time_bin_counts.rename(columns={'request_count': 'article_count'}, inplace=True)
    else:
        time_bin_counts = df.groupby(['event_id', 'time_bin'], observed=True).size().reset_index(name='article_count')

    # Create a full range of time bins for each event_id
    total_hours_before = before_weeks * 7 * 24
    total_hours_after = after_weeks * 7 * 24
    bins = pd.interval_range(start=-total_hours_before, end=total_hours_after, freq=binning_hours)
    df_bins = pd.DataFrame({'time_bin': bins, 'key': 1})
    df_events = pd.DataFrame({'event_id': event_ids, 'key': 1})
    df_time_bins = df_events.merge(df_bins, on='key').drop('key', axis=1)
    df_time_bins = df_time_bins.merge(time_bin_counts, on=['event_id', 'time_bin'], how='left')
    df_time_bins['article_count'] = df_time_bins['article_count'].fillna(0).astype(int)
    
    # Calculate the center point of each time bin
    df_time_bins['time_center_hours'] = df_time_bins['time_bin'].apply(lambda x: x.left + binning_hours / 2)

    # Calculate cumulative sum or rolling average
    bins_per_day = 24 / binning_hours
    df_time_bins = df_time_bins.sort_values(by=['event_id', 'time_center_hours'])
    df_time_bins['cumulative_articles'] = df_time_bins.groupby('event_id')['article_count'].cumsum()
    df_time_bins['rolling_avg_articles'] = df_time_bins.groupby('event_id')['article_count'].transform(
        lambda x: x.rolling(window=int(bins_per_day * moving_average_day), min_periods=1).mean()
    )
    
    # Select the appropriate column for plotting
    df_time_bins['articles_to_plot'] = df_time_bins['rolling_avg_articles'] if use_rolling_avg else df_time_bins['cumulative_articles']

    return df_time_bins

def get_plot_title_and_label(use_rolling_avg, moving_average_day, binning_hours):
    if use_rolling_avg: 
        title = "Rolling Average (" + str(moving_average_day) + " days) Binned by Hour (" + str(binning_hours) + " hours)"
        y_label = "Rolling Average \n(" + str(moving_average_day) + " days)\n of Articles"
    else: 
        title = "Cumulated Articles Binned by Hour (" + str(binning_hours) + " hours)"
        y_label = "Cumulated Articles"
    return title, y_label

def detect_datetime_columns(df, nrows=20):
    """
    Detects columns in a DataFrame that can be converted to datetime using flexible parsing with dateutil.

    Parameters:
    - df: pandas.DataFrame, the DataFrame to analyze.
    - nrows: int, the number of rows to sample for detecting datetime columns.

    Returns:
    - list: A list of column names that can likely be parsed as datetime.
    """    
    # Sample the DataFrame if it's large to save on processing time
    sample_df = df.head(nrows)
    
    # List to hold names of columns that successfully convert to datetime
    datetime_columns = []

    # Iterate over each column and attempt to convert it to datetime using dateutil's parser
    for column in sample_df.columns:
        try:
            # Apply dateutil's parse to each element of the column
            # We use a lambda function to apply parsing
            sample_df[column].apply(lambda x: parser.parse(x, fuzzy=True))
            # If all calls are successful, add column name to the list
            datetime_columns.append(column)
        except (ValueError, TypeError, parser.ParserError):
            # If an error is raised, the column is not a datetime column
            continue

    return datetime_columns